"""

privy-filter

Photo Privacy Filter for GDPR compliant photo sharing and de-identification/bias removal for machine learning. 

"""



__version__ = "0.1.0"
__author__ = "Matthew Davis"
